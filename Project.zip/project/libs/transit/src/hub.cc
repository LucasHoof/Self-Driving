#include "hub.h"

Hub::Hub(Vector3 pos_) {
    position = pos_;
}